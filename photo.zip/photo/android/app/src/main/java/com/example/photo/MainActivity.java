package com.example.photo;

import io.flutter.embedding.android.FlutterActivity;

public class MainActivity extends FlutterActivity {
}
