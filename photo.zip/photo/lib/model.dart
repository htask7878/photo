class Model {
  static List c_text = [
    "Art",
    "Baby",
    "Coding",
    "Coffee",
  ];
  static List photo = [
    "image/a1.jpg",
    "image/b1.jpg",
    "image/c1.jpg",
    "image/t1.jpg",
  ];
  static List art = [
    "image/a1.jpg",
    "image/a2.jpg",
    "image/a3.jpg",
    "image/a4.jpg",
  ];
  static List baby = [
    "image/b1.jpg",
    "image/b2.jpg",
    "image/b3.jpg",
    "image/b4.jpg",
  ];
  static List code = [
    "image/c1.jpg",
    "image/c2.jpg",
    "image/c3.jpg",
    "image/c4.jpg",
  ];
  static List tea = [
    "image/t1.jpg",
    "image/t2.jpg",
    "image/t3.jpg",
    "image/t4.jpg",
  ];
}
